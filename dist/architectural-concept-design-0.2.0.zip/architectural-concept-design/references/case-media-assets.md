# Controlled Local Case-media Assets

> **Single authority** for optional local visual assets that sit beside the ADR-0003 eight-field cards. This reference implements ADR-0004's visual-asset exception; it never changes a card or creates runtime evidence.

## Read order and authority

Read `attribution-only-case-cards.json` first. Read `case-media-manifest.json` only when a user asks to include an already-selected local visual in one editorial card.

- A `CARD-xxx` object remains the sole card record and always has exactly eight fields.
- The manifest maps one existing card to one local package asset. It is an asset-selection record, not a ninth card field or a research supplement.
- `asset_origin` is either `team_original` or `human_confirmed_publishable_source_media`. It is not an ADR-0001 evidence label, legal advice, a license claim, or a `VERIFIED` status.
- A source-media row must be within the existing 20-card study set, include its individual source locator, and use `human_confirmed_publishable_source_media` exactly. The project lead's scoped ADR-0004 confirmation is the only authorization recorded here.
- A team-original diagram has no external source locator. It visualizes only the team's own operation abstraction and must not copy a plan, drawing, caption, or source text.

## Manifest contract

The root object contains `format`, `card_source`, and `media`. Each media record contains exactly:

| Field | Rule |
| --- | --- |
| `card_id` | One existing `CARD-xxx`. |
| `asset_path` | Package-root-relative local path under `assets/case-media/`; never a URL. |
| `asset_kind` | `diagram` or `photo`. |
| `asset_origin` | `team_original` or `human_confirmed_publishable_source_media`. |
| `asset_source_locator` | `null` for a team-original diagram; individual URL for selected source media. |
| `source_accessed_on` | `null` for a team-original diagram; manual access date for selected source media. |
| `selection_status` | `team_original` or `human_confirmation_recorded`. |
| `alt_text` | Concise team-authored accessibility description. |
| `asset_sha256` | SHA-256 of the packaged local file. |

## Presentation rules

- Resolve one matching manifest row locally before inserting `{{media_asset_path}}` and `{{media_alt_text}}` into the 3:4 template.
- Keep the image path local. Do not put a remote URL, `iframe`, script, `fetch`, stylesheet import, or remote font in the template or rendered card.
- Do not browse, query, re-check, or download a source during card rendering. If a manifest row or local asset is missing, render the existing card without media and report the missing asset.
- Keep the source media separate from the card's visible attribution link. The card link remains attribution for the original abstraction; it is not a media license statement.

## Boundaries

- Do not add a ninth field, quotation, research note, `SRC-xxx`, `E-xxx`, or evidence label to `CARD-xxx`.
- Do not add a new source-media row beyond the 20 existing cards without a new human confirmation and reviewed ARCH task.
- Do not create a crawler, bulk downloader, Web gallery, external search, database, API, or online asset service.
- Do not treat an optional local visual as architectural verification, professional guidance, or a substitute for runtime evidence registration.
