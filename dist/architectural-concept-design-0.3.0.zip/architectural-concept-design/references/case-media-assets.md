# Release Case-media Assets

This release archive contains only team-original local diagrams listed in `case-media-manifest.json`. The manifest is an asset-selection record, not an architectural-evidence record, license statement, or verification status.

## Release-package boundary

- Each retained asset is package-root-relative under `assets/case-media/` and has a SHA-256 recorded in the manifest.
- Missing optional media leaves an editorial card without media; do not fetch, download, or substitute content during rendering.
- Optional visuals do not create evidence, change a card record, establish rights, or prove architectural correctness.
